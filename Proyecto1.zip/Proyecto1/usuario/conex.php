<?php
$host = 'localhost'; // Host de la base de datos
$dbname = 'togueterpets'; // Nombre de la base de datos
$username = 'root'; // Usuario de la base de datos
$password = ''; // Contraseña del usuario

try {
    // Crear conexión PDO
    $conexion = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Establecer el modo de error a excepción
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Si ocurre un error, mostrar mensaje
    echo "Error al conectar a la base de datos: " . $e->getMessage();
}
?>
