<?php
// Datos de la base de datos
$host = 'localhost'; // Host de la base de datos
$dbname = 'mi_base_de_datos'; // Nombre de la base de datos principal
$username = 'root'; // Usuario de la base de datos
$password = ''; // Contraseña del usuario

// ID del usuario (puede ser pasado por GET o POST)
$id_usuario = 1; // Este es solo un ejemplo. Deberías obtenerlo dinámicamente.

// Conexión a la base de datos principal (togueterpets)
try {
    $conexion = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Conexión a la segunda base de datos (mi_base_de_datos)
    $conexion_otra = new PDO("mysql:host=$host;dbname=mi_base_de_datos", $username, $password);
    $conexion_otra->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Consulta para obtener nombre y apellido desde mi_base_de_datos
    $query = "SELECT nombre, apellido FROM usuario WHERE id = :id";
    $stmt = $conexion_otra->prepare($query);
    $stmt->bindParam(':id', $id_usuario, PDO::PARAM_INT);
    
    // Ejecutar la consulta
    $stmt->execute();
    
    // Obtener los datos
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $nombre = $result['nombre'];
        $apellido = $result['apellido'];
    } else {
        echo "No se encontró el usuario con ID $id_usuario.";
        exit;
    }

} catch (PDOException $e) {
    // Manejar errores de conexión
    echo "Error al conectar a la base de datos: " . $e->getMessage();
}
?>