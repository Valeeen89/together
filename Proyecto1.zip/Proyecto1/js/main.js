document.addEventListener('DOMContentLoaded', function() {
    // Obtener los elementos de los filtros
    const filtroTamano = document.getElementById('filtro-tamano');
    const filtroSexo = document.getElementById('filtro-sexo');

    // Obtener los botones de categorías
    const botonesCategoria = document.querySelectorAll('.boton-categoria');

    // Obtener todos los productos
    const productos = document.querySelectorAll('.producto');

    // Función para filtrar productos
    function filtrarProductos() {
        const tamanoSeleccionado = filtroTamano.value;
        const sexoSeleccionado = filtroSexo.value;
        const categoriaSeleccionada = document.querySelector('.boton-categoria.active')?.id || 'todos';

        productos.forEach(producto => {
            const tamanoProducto = producto.getAttribute('data-tamano');
            const sexoProducto = producto.getAttribute('data-sexo');
            const tipoProducto = producto.getAttribute('data-tipo');

            const mostrar = (categoriaSeleccionada === 'todos' || tipoProducto === categoriaSeleccionada) &&
                            (tamanoSeleccionado === 'todos' || tamanoProducto === tamanoSeleccionado) &&
                            (sexoSeleccionado === 'todos' || sexoProducto === sexoSeleccionado);

            producto.style.display = mostrar ? 'block' : 'none';
        });
    }

    // Añadir event listeners a los filtros
    filtroTamano.addEventListener('change', filtrarProductos);
    filtroSexo.addEventListener('change', filtrarProductos);

    // Añadir event listeners a los botones de categorías
    botonesCategoria.forEach(boton => {
        boton.addEventListener('click', function() {
            botonesCategoria.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            filtrarProductos();
        });
    });

    // Inicializar el filtrado al cargar la página
    filtrarProductos();
});
document.addEventListener('DOMContentLoaded', function() {
    // Obtener los elementos de los filtros
    const filtroTamano = document.getElementById('filtro-tamano');
    const filtroSexo = document.getElementById('filtro-sexo');

    // Obtener los botones de categorías
    const botonesCategoria = document.querySelectorAll('.boton-categoria');

    // Obtener todos los productos
    const productos = document.querySelectorAll('.producto');

    // Función para filtrar productos
    function filtrarProductos() {
        const tamanoSeleccionado = filtroTamano.value;
        const sexoSeleccionado = filtroSexo.value;
        const categoriaSeleccionada = document.querySelector('.boton-categoria.active')?.id || 'todos';

        productos.forEach(producto => {
            const tamanoProducto = producto.getAttribute('data-tamano');
            const sexoProducto = producto.getAttribute('data-sexo');
            const tipoProducto = producto.getAttribute('data-tipo');

            const mostrar = (categoriaSeleccionada === 'todos' || tipoProducto === categoriaSeleccionada) &&
                            (tamanoSeleccionado === 'todos' || tamanoProducto === tamanoSeleccionado) &&
                            (sexoSeleccionado === 'todos' || sexoProducto === sexoSeleccionado);

            producto.style.display = mostrar ? 'block' : 'none';
        });
    }

    // Añadir event listeners a los filtros
    filtroTamano.addEventListener('change', filtrarProductos);
    filtroSexo.addEventListener('change', filtrarProductos);

    // Añadir event listeners a los botones de categorías
    botonesCategoria.forEach(boton => {
        boton.addEventListener('click', function() {
            botonesCategoria.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            filtrarProductos();
        });
    });

    // Inicializar el filtrado al cargar la página
    filtrarProductos();
});


