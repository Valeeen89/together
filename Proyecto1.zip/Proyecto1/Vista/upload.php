<?php
session_start();

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$host = "localhost"; // Cambia según tu configuración
$user = "root"; // Usuario de la base de datos
$password = ""; // Contraseña de la base de datos
$dbname = "mi_base_de_datos"; // Cambia al nombre de tu base de datos
$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Manejo del archivo subido
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $usuarios = $_SESSION['usuario'];
    $userId = $usuarios['id']; // Asegúrate de tener el `id` del usuario en la sesión

    $imageName = $_FILES['image']['name'];
    $imageTmpName = $_FILES['image']['tmp_name'];
    $uploadDir = 'uploads/'; // Ruta relativa al directorio del proyecto
    $imagePath = $uploadDir . uniqid() . "_" . basename($imageName);

    // Mover la imagen al directorio 'uploads'
    if (move_uploaded_file($imageTmpName, $imagePath)) {
        // Guarda la ruta en la base de datos
        $stmt = $conn->prepare("UPDATE usuarios SET foto = ? WHERE id = ?");
        $stmt->bind_param("si", $imagePath, $userId);

        if ($stmt->execute()) {
            $_SESSION['image'] = $imagePath; // Actualiza la sesión con la nueva imagen
            echo "Imagen guardada correctamente.";
        } else {
            echo "Error al guardar la ruta en la base de datos.";
        }
        $stmt->close();
    } else {
        echo "Error al mover el archivo.";
    }
} else {
    echo "No se ha subido ninguna imagen o hubo un error.";
}

$conn->close();
?>
<?php if (isset($_SESSION['image']) && !empty($_SESSION['image'])): ?>
    <img src="<?php echo $_SESSION['image']; ?>" alt="Imagen de Perfil" style="max-width: 200px; height: auto;">
<?php endif; ?>
