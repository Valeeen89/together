<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Responsive Mark Express</title>
    <link rel="stylesheet" href="../css/noticias.css">
</head>
<body>
    <!-- BARRA DE NAVEGACIÓN -->
    <header class="header">
        <div class="logo">
          <img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca" href="../Index.html"></img>
        </div>
        <nav>
          <ul class="nav-links">
              <li><a class="active" href="../Index.html">Inicio</a></li>
              <li><a href="../Vista/peluditos.php">Peluditos </a></li>
              <li><a href="../Vista/noticias.php">Noticias </a></li>
              <li><a href="../Vista/comoadoptar.html">¿Como Adoptar?</a></li>
              
          </ul>
      </nav>
      <div>
          <a href='../Vista/registro.php' class="btn"><button>registrarse</button></a>
          <a href='../Vista/login.php' class="btn"><button>Inicio de sesion</button></a>
      </div>
  </header>
    
    <!-- SECCIÓN DE NOTICIAS -->
    <div class="container">
        <h1>NOTICIAS MAS RECIENTES</h1>
        <header class="news-header">
            <nav class="categories">
                <span class="cat" onclick="buscar('todos')">Todo</span>
                <span class="cat" onclick="buscar('mascotaP')">Mascotas perdidas</span>
                <span class="cat" onclick="buscar('mascotaE')">Mascotas encontradas</span>
                <span class="cat" onclick="buscar('rescates')">Rescates</span>
                <span class="cat" onclick="buscar('educación')">Historias</span>
            </nav>
            <div class="search-bar">
                <input type="text" placeholder="Qué desea buscar" id="busqueda">
                <button onclick="buscarTema()">Buscar</button>
            </div>
        </header>
        
        <div class="container-card">
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not4.jpg" alt="rescates">
                </figure>
                <div class="contenido-card">
                    <h3>¡Gato Atropellado se Recupera Gracias a una Compleja Cirugía!</h3>
                    <p>Nos alegra informar que el valiente gatito, que fue atropellado en una calle de la ciudad, está en proceso de recuperación tras una cirugía exitosa realizada por el equipo veterinario de Together Pets.</p>
                    <a href="noti1.html">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not10.webp" alt="mascotaE">
                </figure>
                <div class="contenido-card">
                    <h3>¡Perro Perdido Reencuentra a Su Familia Después de Dos Años!</h3>
                    <p>Nos llena de alegría compartir la emotiva historia del reencuentro de un perro perdido con su familia después de dos años. Together Pets tuvo el honor de ser parte de este conmovedor momento.</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not11.jfif" alt="mascotaP">
                </figure>
                <div class="contenido-card">
                    <h3>!Perro perdido por los lados de la plaza de paloquemado¡</h3>
                    <p>Alaska una perrita criolla se perdio el pasado dia 10 de agosto por la paza de paloquemado cualquier informacion comicarse a los siguientes numeros...</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not12.png" alt="educación">
                </figure>
                <div class="contenido-card">
                    <h3>¡Veterinario Viaja a Zonas Rurales para Brindar Atención Gratuita a Animales!</h3>
                    <p>En una destacada iniciativa para apoyar a comunidades rurales, Together Pets ha enviado a un veterinario experimentado para proporcionar atención médica gratuita a animales en zonas alejadas.</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
            <div class="card">
                <figure>
                    <img src="../img/Noticias/not7.jpg" alt="educación">
                </figure>
                <div class="contenido-card">
                    <h3>¡Veterinarios en Acción: Operación Gratuita para Mascotas de Familias de Bajos Recursos!</h3>
                    <p>Nos complace anunciar que Together Pets, en colaboración con un grupo de veterinarios voluntarios, ha llevado a cabo una operación gratuita para mascotas de familias de bajos recursos. Este evento ha brindado cuidados veterinarios esenciales a muchas mascotas que de otro modo no podrían haber recibido tratamient.</p>
                    <a href="#">Leer más</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- PIE DE PÁGINA -->
    <footer class="footer">
        <div class="footer-section logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo" class="logo-img">
        </div>
        <div class="copyright">
            <p>Proyecto de Adopción y Bienestar Animal Together Pets &copy; 2024</p>
        </div>
    </footer>
    <script src="../js/filtronoticias.js"></script>
</body>
</html>
