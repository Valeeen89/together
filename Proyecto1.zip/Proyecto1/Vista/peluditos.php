<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-UA-Compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>complete responsive mark express</title>
	<link rel="stylesheet" href="../css/peluditos.css">
</head>
<body>

<header class="header">
        <div class="logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="logo de la marca">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a class="active" href="../Index.html">Inicio</a></li>
                <li><a href="../Vista/peluditos.php">Peluditos </a></li>
                <li><a href="../Vista/noticias.php">Noticias </a></li>
                <li><a href="../Vista/comoadoptar.html">¿Cómo Adoptar? </a></li>
            </ul>
        </nav>
        <div>
            <a href='../Vista/registro.php' class="btn"><button>Registrarse</button></a>
        </div>
    </header>
    <div class="wrapper">
        <header class="header-mobile">
            <h1 class="logo">CarpiShop</h1>
            <button class="open-menu" id="open-menu">
                <i class="bi bi-list"></i>
            </button>
        </header>
        <aside>

            <header>
                <h1 class="logo">Adopta a tu próximo Amigo...</h1>
            </header>
            <nav>
                <ul class="menu">
                    <li>
                        <button id="todos" class="boton-menu boton-categoria active"><i class="bi bi-hand-index-thumb-fill"></i> Todos</button>
                    </li>
                    <li>
                        <button id="perros" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i> Perros</button>
                    </li>
                    <li>
                        <button id="gatos" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i> Gatos</button>
                    </li>
                </ul>
            </nav>
            <footer>
                <p class="texto-footer">© 2022 Carpi Coder</p>
            </footer>
        </aside>
        <main>
            <!-- Filtros -->
            <div class="filtros">
                <label for="filtro-tamano">Tamaño:</label>
                <select id="filtro-tamano">
                    <option value="todos">Todos</option>
                    <option value="grande">Grande</option>
                    <option value="mediano">Mediano</option>
                    <option value="pequeno">Pequeño</option>
                </select>

                <label for="filtro-sexo">Sexo:</label>
                <select id="filtro-sexo">
                    <option value="todos">Todos</option>
                    <option value="hembra">Hembra</option>
                    <option value="macho">Macho</option>
                </select>
            </div>

            <div id="contenedor-productos" class="contenedor-productos">
                <!-- GATOS -->
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g1.png" alt="Arlequin">
                    <a href="../adopcion/ad1.html" class="enlace-animal">Arlequin</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g2.jpg" alt="Alex">
                    <a href="../adopcion/ad2.html" class="enlace-animal">Alex</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g3.jpeg" alt="Bibi">
                    <a href="../adopcion/ad3.html" class="enlace-animal">Bibi</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g4.jpeg" alt="Casper">
                    <a href="../adopcion/ad4.html" class="enlace-animal">Casper</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="gatos">
                    <img src="../img/g5.jpeg" alt="Chocolate">
                    <a href="../adopcion/ad5.html" class="enlace-animal">Chocolate</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g6.jpeg" alt="Flor">
                    <a href="../adopcion/ad6.html" class="enlace-animal">Flor</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g7.jpeg" alt="Lulu">
                    <a href="../adopcion/ad7.html" class="enlace-animal">Lulu</a>
                </div>
                <div class="producto" data-sexo="hembra" data-tipo="gatos">
                    <img src="../img/g8.jpeg" alt="Marina">
                    <a href="../adopcion/ad8.html" class="enlace-animal">Marina</a>
                </div>
                <!-- PERROS -->
                <div class="producto" data-tamano="grande" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe1.jpeg" alt="Ragna">
                    <a href="../adopcion/ad9.html" class="enlace-animal">Ragna</a>
                </div>
                <div class="producto" data-tamano="mediano" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe2.jpg" alt="Tuso">
                    <a href="../adopcion/ad10.html" class="enlace-animal">Tuso</a>
                </div>
                <div class="producto" data-tamano="pequeno" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe3.jpeg" alt="Leo">
                    <a href="../adopcion/ad11.html" class="enlace-animal">Leo</a>
                </div>
                <div class="producto" data-tamano="mediano" data-sexo="macho" data-tipo="perros">
                    <img src="../img/pe4.jpeg" alt="Gus">
                    <a href="../adopcion/ad12.html" class="enlace-animal">Gus</a>
                </div>
                <div class="producto" data-tamano="pequeno" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe5.jpeg" alt="Nana">
                    <a href="../adopcion/ad13.html" class="enlace-animal">Nana</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe6.jpg" alt="Coral">
                    <a href="../adopcion/ad14.html" class="enlace-animal">Coral</a>
                </div>
                <div class="producto" data-tamano="mediano" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe7.jpeg" alt="Kuka">
                    <a href="../adopcion/ad15.html" class="enlace-animal">Kuka</a>
                </div>
                <div class="producto" data-tamano="grande" data-sexo="hembra" data-tipo="perros">
                    <img src="../img/pe8.jpg" alt="Lexi">
                    <a href="../adopcion/ad16.html" class="enlace-animal">Lexi</a>
                </div>
            </div>
        </main>
    </div>
    <footer class="footer">
        <div class="container container-footer">
            <div class="footer-section logo">
                <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo" class="logo-img">
            </div>
        </div>
        <br>
        <div class="copyright">
            <p>Proyecto de Adopción y Bienestar Animal Together Pets &copy; 2024</p>
        </div>
    </footer>
    
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="../js/main.js"></script>
</body>
</html>
