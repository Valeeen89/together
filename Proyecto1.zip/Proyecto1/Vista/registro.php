<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    // Eliminar la encriptación de la contraseña
    $contrasena = $_POST['contrasena']; // Almacenar la contraseña en texto plano

    $sql = "INSERT INTO usuarios (nombre, apellido, direccion, telefono, correo, contrasena) VALUES ('$nombre', '$apellido', '$direccion', '$telefono', '$correo', '$contrasena')";

    if ($conn->query($sql) === TRUE) {
        // Redirigir a la página de login después de un registro exitoso
        header("Location: login.php");
        exit(); // Asegúrate de llamar a exit después de header
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Mark Express</title>
    <link rel="stylesheet" href="../css/registro.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap">
</head>
<body>
    <header class="header">
        <div class="logo">
            <img src="../img/Logo_con_letras-removebg-preview.png" alt="Logo de la marca">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a class="active" href="../Index.html">Inicio</a></li>
                <li><a href="../Vista/peluditos.php">Peluditos</a></li>
                <li><a href="../Vista/noticias.php">Noticias</a></li>
                <li><a href="../Vista/comoadoptar.html">¿Como Adoptar?</a></li>
            </ul>
        </nav>
        <div class="btn-container">
            <a href='../Vista/login.php' class="btn"><button>Iniciar Sesión</button></a>
        </div>
    </header>
   
        <br>
        <br>
        <br>
    <main class="main-content"> <!-- Registro -->
        <div class="form-box">
            <div class="register-container" id="register">
                <header>Registrarse</header>
                <form action="" name="toguetherpets" method="POST">
                    <div class="two-forms">
                        <div class="input-box">
                          Nombre  <input type="text" name="nombre" id="firstName" class="input-field" required>
                        </div>
                        <div class="input-box">
                          Apellido  <input type="text" name="apellido" id="LastName" class="input-field" required>
                        </div>
                    </div>
                    <div class="input-box">
                        Direccion<input type="text" name="direccion" class="input-field" required>
                    </div>
                    <div class="input-box">
                       Telefono <input type="text" name="telefono" class="input-field"required>
                    </div>
                    <div class="input-box">
                       Correo <input type="email" name="correo" id="email" class="input-field"required>
                    </div>
                    <div class="input-box">
                        Contraseña<input type="password" name="contrasena" id="password" class="input-field" required>
                    </div>
                    <div class="input-box">
                        <input type="submit" class="submit" value="Registrar">
                    </div>
                    <div class="two-col">
                        <div class="one">
                            <input type="checkbox" id="register-check">
                            <label for="register-check"> Recordar</label>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
</body>
</html>